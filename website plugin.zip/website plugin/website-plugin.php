<?php
/**
 * Plugin Name: CUSTOM WEBSITES PLUGIN
 * Description: A plugin that adds a form on the front-end to submit websites on custom post types(WEBSITES) as post.
 * Version: 1.0
 * Author: Roshina Syed
 *
 */
// Silence is Gold => Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}
// Enqueue the Style file.
function websites_enqueue_styles() {
    wp_enqueue_style('websites-form-css', plugin_dir_url(__FILE__) . 'websites-form.css');
}
add_action('wp_enqueue_scripts', 'websites_enqueue_styles');

/////////////////////////////////////////////////////////////
// Step1: Creating the Custom POST TYPE Named as WEBSITES
////////////////////////////////////////////////////////////
function register_websites() {
    $labels = array(
        'name' => 'WEBSITES',
        'singular_name' => 'WEBSITES',
        'edit_item' => 'Edit WEBSITES',
        'new_item' => 'New WEBSITES',
        'view_item' => 'View WEBSITES',
        'search_items' => 'Search WEBSITES',
        'not_found' => 'No WEBSITES found',
        'not_found_in_trash' => 'No WEBSITES found in trash',
        'all_items' => 'All WEBSITES',
        'menu_name' => 'WEBSITES',
    );
    
    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true, 
        'supports' => array('title', 'custom-fields'),
        'capabilities' => array(
            'create_posts' => 'do_not_allow', // Disable the user for Add New
        ),
        'map_meta_cap' => true, 
    );
    
    register_post_type('WEBSITES', $args);
}
add_action('init', 'register_websites');

/////////////////////////////////////////////////////////////
// Step2: Create The WEBSITE FORM
////////////////////////////////////////////////////////////
function create_website_form() {
    if (isset($_POST['submit_form'])) {
        $name = sanitize_text_field($_POST['website_name']);
        $url = esc_url($_POST['website_url']);

        // Insert the custom post into the WEBSITES custom post type
        $post_id = wp_insert_post(array(
            'post_title' => $name,
            'post_type' => 'WEBSITES',
            'post_status' => 'publish',
        ));

        if ($post_id) {
            // Store website URL in post meta
            update_post_meta($post_id, 'website_url', $url);
            echo '<p>Website submitted successfully!</p>';
        }
    }

    ob_start();
    ?>
    <form method="post">
        <div id="form">
            <label for="website_name">Name:</label>
            <input type="text" name="website_name" required>
            
            <label for="website_url">Website URL:</label>
            <input type="url" name="website_url" required>
            
            <input type="submit" name="submit_form" value="Submit Website">
        </div>
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode('customform', 'create_website_form');

/////////////////////////////////////////////////////////////
// Step3: Remove the ability to add new 'Websites' via Admin
////////////////////////////////////////////////////////////
function remove_add_new_websites() {
    remove_submenu_page('edit.php?post_type=WEBSITES', 'post-new.php?post_type=WEBSITES');
}
add_action('admin_menu', 'remove_add_new_websites');

/////////////////////////////////////////////////
// Step4: Remove the metaboxes including publish
////////////////////////////////////////////////
function remove_metaboxes() {
    remove_meta_box('submitdiv', 'WEBSITES', 'side'); 
    remove_meta_box('slugdiv', 'WEBSITES', 'normal'); 
    remove_meta_box('postcustom', 'WEBSITES', 'normal'); 
}
add_action('add_meta_boxes', 'remove_metaboxes');

/////////////////////////////////////////////////////////
// Step5: Add Metabox with Source Code (For Admins)
/////////////////////////////////////////////////////////
function add_source_code_metabox() {
    add_meta_box('WEBSITES_source_code', 'WEBSITES Source Code', 'display_source_code', 'WEBSITES', 'normal', 'high');
}
add_action('add_meta_boxes', 'add_source_code_metabox');

//For display source code function
function display_source_code($post) {
    
    if (current_user_can('administrator')) {
        $url = get_post_meta($post->ID, 'website_url', true);
        $source_code = get_source_code($url);
        echo '<textarea rows="10" style="width:100%;">' . esc_textarea($source_code) . '</textarea>';
    } else {
        echo '<p>Only administrators can see the source code.</p>';
    }
}
//For getting the source code function
function get_source_code($url) {
    $response = wp_remote_get($url);
    if (is_wp_error($response)) {
        return 'Unable to fetch source code.';
    }
    return wp_remote_retrieve_body($response);
}
function register_api_routes() {
    register_rest_route('websitecustomplugin/v1', '/WEBSITES/', array(
        'methods' => 'GET',
        'callback' => 'get_websites',
    ));
}
add_action('rest_api_init', 'register_api_routes');

function get_websites(){
    $args = array(
        'post_type' => 'WEBSITES',
        'posts_per_page' => -1,
    );
    
    $query = new WP_Query($args);
    $websites = array();

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $websites[] = array(
                'name' => get_the_title(),
                'url' => get_post_meta(get_the_ID(), 'website_url', true),
            );
        }
    }
    wp_reset_postdata();

    return $websites;
}
?>